public class HelloWorld {
    public static void main(String[] args) {
        // Imprimir datos
        int numero = 10;
        long numeroLargo = 1000000000L;
        double numeroDecimal = 3.14;
        boolean esVerdadero = true;
        String texto = "Hola, mundo!";
        
        System.out.println("Número: " + numero);
        System.out.println("Número largo: " + numeroLargo);
        System.out.println("Número decimal: " + numeroDecimal);
        System.out.println("¿Es verdadero?: " + esVerdadero);
        System.out.println("Texto: " + texto);
    }
}